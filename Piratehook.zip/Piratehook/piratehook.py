import requests
import os
import time

while True:
    os.system('cls' if os.name == 'nt' else 'clear')  # Clear the screen
    print("Welcome to Piratehook! Menu:")
    print("1. Spam the webhook")
    print("2. Delete the webhook")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("Enter the webhook URL:")
        webhook_url = input()
        if not webhook_url.startswith("https://discord.com/api/webhooks/"):
            print("Invalid webhook! Going back to menu...")
            time.sleep(2)  # Wait for 2 seconds
            continue  # Return to the menu
        else:
            print("Enter the message to spam:")
            message = input()
            print("Enter the number of times to send the message:")
            num_spams = int(input())

            for i in range(num_spams):
                payload = {"content": message}
                response = requests.post(webhook_url, json=payload)
                if response.status_code == 200:
                    print(f"Spam {i+1} sent successfully")
                else:
                    print(f"Error sending spam {i+1}: {response.status_code}")
            print("Spamming complete. Going back to menu...")
            time.sleep(2)  # Wait for 2 seconds
    elif choice == "2":
        print("Enter the webhook URL to delete:")
        webhook_url = input()
        if not webhook_url.startswith("https://discord.com/api/webhooks/"):
            print("Invalid webhook! Going back to menu...")
            time.sleep(2)  # Wait for 2 seconds
            continue  # Return to the menu
        else:
            payload = {"content": f"Deleted webhook by deadlyhook"}
            response = requests.post(webhook_url, json=payload)
            if response.status_code == 200:
                print("Webhook deleted successfully")
                os.remove("webhook.txt")
            else:
                print(f"Error deleting webhook: {response.status_code}")
            print("Deletion complete. Going back to menu...")
            time.sleep(2)  # Wait for 2 seconds